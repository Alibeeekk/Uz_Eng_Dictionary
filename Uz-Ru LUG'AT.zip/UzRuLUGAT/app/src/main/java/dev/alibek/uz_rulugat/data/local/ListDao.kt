package dev.alibek.uz_rulugat.data.local

interface ListDao {
}