package dev.alibek.uz_rulugat.ui.viewpagefragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.navigation.fragment.findNavController
import dev.alibek.uz_rulugat.R


class SaqlanganlarFragment : Fragment(R.layout.fragment_saqlanganlar) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    private fun initViews(view: View) {
        val ivBack:ImageView=view.findViewById(R.id.iv_back)

        ivBack.setOnClickListener {
            findNavController().navigate(R.id.action_saqlanganlarFragment_to_lugatFragment)
        }

    }
}