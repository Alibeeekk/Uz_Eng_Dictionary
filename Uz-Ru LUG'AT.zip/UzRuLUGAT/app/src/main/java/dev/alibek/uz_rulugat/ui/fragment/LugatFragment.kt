package dev.alibek.uz_rulugat.ui.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import dev.alibek.uz_rulugat.R
import dev.alibek.uz_rulugat.utils.LocaleManager
import dev.alibek.uz_rulugat.utils.SharedPrefManager

class LugatFragment : Fragment(R.layout.fragment_lugat) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    @SuppressLint("SetTextI18n")
    private fun initViews(view: View) {

        val tvUZ: TextView = view.findViewById(R.id.tv_uz)
        val tvEN: TextView = view.findViewById(R.id.tv_en)
        val llClick = view.findViewById<LinearLayout>(R.id.ll_click)
        val ivBookmark = view.findViewById<ImageView>(R.id.iv_bookmarks)
        val etSearch = view.findViewById<EditText>(R.id.et_search)

        ivBookmark.setOnClickListener {
            findNavController().navigate(R.id.action_lugatFragment_to_saqlanganlarFragment)
        }

        etSearch

    }

}

