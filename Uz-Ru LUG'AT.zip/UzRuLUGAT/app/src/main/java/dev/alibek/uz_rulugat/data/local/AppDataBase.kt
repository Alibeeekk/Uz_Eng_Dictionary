package dev.alibek.uz_rulugat.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import dev.alibek.uz_rulugat.model.ListModel

@Database(entities = [ListModel::class], version = 1)
abstract class AppDataBase {


}