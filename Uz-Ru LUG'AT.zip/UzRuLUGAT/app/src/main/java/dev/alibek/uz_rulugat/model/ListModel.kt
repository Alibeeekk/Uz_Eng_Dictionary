package dev.alibek.uz_rulugat.model

import android.widget.ImageView
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lugat")
data class ListModel(
    val title:String,
    val ivSaves: ImageView,
    @PrimaryKey
    val id:Int
    )
